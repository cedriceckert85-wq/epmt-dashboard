# So schickst du mir die Beispiel-Videos (für Insta, YT und Uncut)

Kurz zum Verständnis: Meine Software lernt von Beispiel-Clips, **wie die
Videos auf jedem unserer Kanäle aussehen sollen** — Länge, Schnitt-Tempo,
Humor, Captions. Danach sortiert sie automatisch: „Das wird ein Insta-Clip",
„das kommt ins YT-Video", „das bleibt im Uncut".

Dafür brauche ich Beispiele, **getrennt nach den drei Kanälen**.

**WICHTIG:** Das sind **fertige, geschnittene Videos** — so wie sie am Ende
online aussehen sollen. NICHT deine rohen Stream-Aufnahmen! Also: fertige
Reels, fertige YouTube-Videos. Deine besten eigenen Uploads oder Videos von
anderen Creators, deren Stil wir genau so wollen.

---

## Was ich pro Kanal brauche

**1. INSTA** (Reels / Kurzform, vertikal) — hier gibt es ZWEI Sorten,
bitte getrennt halten:
- **INSTA-FUNNY:** fertige Funny-Talk-Reels (lustige Moment-Clips) — 5-15 Stück
- **INSTA-MONTAGE:** fertige Montage-Reels (schnell geschnittene Play-Zusammenschnitte) — 5-15 Stück
- Wenn wir noch mehr Insta-Sorten haben: einfach weitere Gruppen aufmachen

**2. YT** (Hauptkanal):
- Fertige Highlight-Videos, wie unser Hauptkanal aussehen soll
  (typisch 5-15 Minuten geschnittenes Video)
- **5-10 Stück**, alle vom gleichen Typ

**3. UNCUT** (Ganze Sessions):
- **2-3 Beispiele reichen hier!** Uncut ist ja fast ungeschnitten — wichtig
  ist nur, wie sowas aufgebaut ist (Intro? Kapitel? einfach roh?)

Goldene Regel für ALLE drei: nur Videos, bei denen du sagst „GENAU so will
ich das" — nicht „ganz ok". Und pro Kanal nicht mischen: wenn in „insta" zwei
völlig verschiedene Arten von Reels liegen, lernt die Software Einheitsbrei.

---

## Variante A — Die einfache: Schick mir nur Links

Nichts runterladen, einfach eine Liste mit Links, sortiert nach Kanal:

```
INSTA - FUNNY (lustige Talk-Reels):
https://youtube.com/shorts/xxxxx
... (5-15 Links)

INSTA - MONTAGE (Play-Zusammenschnitte):
https://www.instagram.com/reel/yyyyy
... (5-15 Links)

YT (Hauptkanal-Videos):
https://youtube.com/watch?v=aaaaa
... (5-10 Links)

UNCUT:
https://youtube.com/watch?v=bbbbb
... (2-3 Links)
```

Fertig. Mehr musst du nicht tun.

---

## Variante B — Als Dateien schicken

**1. Bau auf deinem PC GENAU diese Ordner:**

```
beispiele\
   insta\
      reel1.mp4
      reel2.mp4
      ... (5-15 Stück)
   yt\
      video1.mp4
      ... (5-10 Stück)
   uncut\
      session1.mp4
      ... (2-3 Stück)
```

Regeln:
- **Ordnernamen exakt so:** `insta` (mit `funny` und `montage` darin), `yt`, `uncut` — klein geschrieben,
  keine Leerzeichen, keine Emojis (die Namen sind für die Software!)
- Formate: **mp4, mkv, webm, mov** — was von YouTube/Insta kommt, passt
- Dateinamen egal, aber simpel

**2. Den ganzen `beispiele`-Ordner als ZIP packen:**
- Rechtsklick auf den Ordner → **„Senden an" → „ZIP-komprimierter Ordner"**
  (Windows 11: „In ZIP-Datei komprimieren")
- Das ZIP behält die Ordner — genau die brauche ich!

**3. Schicken:**
- Google Drive / Dropbox → „Link teilen", oder **swisstransfer.com**
  (kostenlos bis 50 GB, ohne Anmeldung)
- Achtung: die Uncut-Beispiele können groß sein → dann lieber SwissTransfer

**Was du NICHT machen sollst:**
- ❌ Nicht per WhatsApp als „Video" schicken (zerstört die Qualität) —
  höchstens als **Dokument/Datei**
- ❌ Nicht alles lose in EINEN Ordner werfen — ohne die drei Kanal-Ordner
  weiß die Software nicht, was wohin gehört
- ❌ Keine rohen Stream-Mitschnitte — nur fertige Videos

---

## Kurz-Checkliste

1. ☐ Fertige Videos ausgesucht (keine rohen VODs)
2. ☐ Vier Gruppen: **insta-funny** (5-15) / **insta-montage** (5-15) /
   **yt** (5-10) / **uncut** (2-3)
3. ☐ Pro Gruppe nur ein Typ, nur echte „genau so!"-Beispiele
4. ☐ Variante A: Linkliste mit den vier Überschriften — ODER —
   Variante B: Ordner insta\funny\ insta\montage\ yt\ uncut\ → ZIP → Drive/SwissTransfer
5. ☐ Link an mich

Unsicher bei einem Video? Mitschicken und ein Fragezeichen dahinter. 🙂
