# So schickst du mir deine VODs (Schritt für Schritt)

Hey! Damit ich aus deinen Streams automatisch Clips machen kann, brauche ich
deine Aufnahmen in einem bestimmten Setup. Ist einmalig 5 Minuten Einstellen,
danach musst du nie wieder dran denken. Mach einfach genau das hier:

---

## Variante A — Die einfache (wenn du auf Twitch streamst)

Wenn deine Streams eh als VOD auf Twitch liegen:

**Schick mir einfach nur den Link zum VOD.** Fertig. Mehr musst du nicht tun.

(Ich lade ihn mir selbst runter. Qualität ist etwas schlechter als Variante B,
weil Game-Sound und deine Stimme auf einer Spur gemischt sind — aber es
funktioniert.)

---

## Variante B — Die richtige (OBS-Aufnahme, beste Qualität)

### Schritt 1: Einmalig OBS einstellen (5 Minuten)

**1. Ausgabemodus umstellen:**
- OBS öffnen → oben **Datei** → **Einstellungen** → links **Ausgabe**
- Ganz oben bei **Ausgabemodus**: auf **„Erweitert"** stellen
  (im Modus „Einfach" gibt es die Audiospuren nicht!)

**2. Aufnahme-Einstellungen:**
- Immer noch unter **Ausgabe**: oben auf den Reiter **„Aufnahme"** klicken
- **Aufnahmeformat**: auf **mkv** stellen (heißt evtl. „Matroska (.mkv)")
  → Warum: Wenn dein PC abstürzt, ist die Aufnahme trotzdem nicht kaputt
- **Audiospur**: Häkchen bei **1 UND 2** setzen (zwei Häkchen!)
- Unten **Übernehmen** klicken

**3. Deine Stimme auf eine eigene Spur legen:**
- Einstellungen-Fenster schließen
- Im Hauptfenster unten im Kasten **„Audio-Mixer"**: auf das kleine
  **Zahnrad** neben irgendeinem Regler klicken → **„Erweiterte
  Audioeigenschaften"**
- Da ist jetzt eine Tabelle mit Spalten „Spuren 1 2 3 4 5 6". Stell ein:
  - Zeile **Mikrofon** (dein Mic): Häkchen bei **1 und 2**
  - Zeile **Desktop-Audio** (Game-Sound): Häkchen **nur bei 1** (Haken bei 2 RAUSNEHMEN)
  - Falls du Musik/Discord als eigene Quelle hast: auch **nur Spur 1**
- Schließen. Fertig — das war die ganze Magie.

**Was du damit gebaut hast:** Spur 1 = alles gemischt (ganz normal zum
Anschauen), Spur 2 = NUR deine Stimme. Meine Software hört auf Spur 2, wo du
lachst und ausrastest — so findet sie die besten Momente, ohne dass
Teamfight-Explosionen sie verwirren.

### Schritt 2: Aufnehmen

- Im OBS-Hauptfenster rechts unten: **„Aufnahme starten"** klicken
  (NICHT „Stream starten" — du kannst auch beides gleichzeitig)
- Zocken wie immer. Laufen lassen, nicht zwischendurch stoppen.
- Am Ende: **„Aufnahme stoppen"**

### Schritt 3: Die Datei finden

- **Datei** → **Einstellungen** → **Ausgabe** → Reiter **Aufnahme** →
  bei **„Aufnahmepfad"** steht der Ordner
- Standard ist meistens: `C:\Users\DEINNAME\Videos`
- Die Datei heißt sowas wie `2026-08-12 20-15-33.mkv`

### Schritt 4: WICHTIG — was du NICHT machen darfst

- ❌ **NICHT durch WhatsApp als Video schicken** (WhatsApp zerquetscht die Datei)
- ❌ **NICHT vorher schneiden oder durch einen Editor exportieren**
  (dabei geht die zweite Tonspur verloren!)
- ❌ **NICHT in ein anderes Format umwandeln** — die .mkv so lassen, wie sie ist
- ✅ Umbenennen ist ok, aber bitte simpel: `stream_12_08.mkv`
  (keine Sonderzeichen, keine Emojis im Dateinamen)

### Schritt 5: Schicken

Die Dateien sind GROSS (mehrere GB), also:

- **Am besten:** Google Drive / Dropbox / OneDrive → Datei hochladen →
  „Link teilen" → Link an mich (bei Google Drive: Rechtsklick auf die Datei →
  „Freigeben" → „Jeder mit dem Link" → Link kopieren)
- **Auch gut:** swisstransfer.com — kostenlos bis 50 GB, ohne Anmeldung:
  Datei hochladen, Link an mich
- **Oder ganz klassisch:** USB-Stick / externe Festplatte beim nächsten Treffen
- **Geht NICHT:** normale Discord/WhatsApp-Anhänge (zu groß bzw. wird zerstört)

---

## Kurz-Checkliste (zum Abhaken)

1. ☐ OBS: Ausgabemodus „Erweitert"
2. ☐ Aufnahmeformat mkv, Audiospur 1 + 2 angehakt
3. ☐ Erweiterte Audioeigenschaften: Mic auf Spur 1+2, Game-Sound nur Spur 1
4. ☐ Mit „Aufnahme starten" aufgenommen (ganze Session, nicht stoppen)
5. ☐ Datei NICHT umgewandelt/geschnitten
6. ☐ Per Drive-Link / SwissTransfer / Festplatte an mich

Bei Fragen einfach Screenshot von deinem OBS schicken, dann sag ich dir, wo
der Haken fehlt. 🙂
